package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SignUpT extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_t);
        getSupportActionBar().hide();
    }
    public void lug(View v) {
        startActivity(new Intent(SignUpT.this,TeacherHome.class));
    }


    public void sug(View v) {
        startActivity(new Intent(SignUpT.this,TeacherHome.class));
    }


}